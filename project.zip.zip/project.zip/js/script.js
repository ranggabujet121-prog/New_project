const noBtn = document.getElementById("noBtn");

function kabur() {
  const x = Math.random() * (window.innerWidth - noBtn.offsetWidth);
  const y = Math.random() * (window.innerHeight - noBtn.offsetHeight);

  noBtn.style.position = "absolute";
  noBtn.style.left = x + "px";
  noBtn.style.top = y + "px";
}

// PC
noBtn.addEventListener("mouseover", kabur);

// HP
noBtn.addEventListener("touchstart", kabur);